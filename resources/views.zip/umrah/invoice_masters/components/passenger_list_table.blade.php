<div class="row">
<div class="col-md-6">
    <div class="panel-heading bg-danger bg-gradient" >
<h6 align="center" style="padding: 1%; margin: 0; color:#fff;"><span class="fa fa-edit"></span> &nbsp;Pending Passenger</h6>
</div>


    <table id="passenger-table" class="table table-sm table-bordered" style="width: 100%;">
    <thead>
        <tr>
            <td width="20%">Passport No</td>
            <td width="20%">Pax Name</td>
            <td width="10%">Type</td>
            <td width="10%">Rel. Type</td>
            <td width="10%">Action</td>
        </tr>
    </thead>
</table>
</div>
<div class="col-md-6">
    <div class="panel-heading bg-success bg-gradient" >
<h6 align="center" style="padding: 1%; margin: 0; color:#fff;"><span class="fa fa-user"></span> &nbsp;Voucher Allocated Passenger</h6>
</div>
    <table id="passenger-table1" class="table table-sm table-bordered">
    <thead>
        <tr>
            <td width="20%">Passport No</td>
            <td width="20%">Pax Name</td>
            <td width="10%">Type</td>
            <td width="10%">Rel. Type</td>
            <td width="10%">Action</td>
        </tr>
    </thead>
</table></div>
</div>