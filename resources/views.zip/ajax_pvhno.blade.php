<input type="text"  class="form-control" name="Voucher" id="Voucher" value="{{$d['VocherCode']}}{{substr($d['VHDate'],2,6)}}{{$data[0]->vhno}}" >


 
